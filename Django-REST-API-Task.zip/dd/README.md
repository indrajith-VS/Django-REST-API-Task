# Django Login API

This project provides a minimal Django REST Framework setup with a login endpoint that returns a DRF auth token.

## Setup

```bash
python -m venv venv
venv\Scripts\python -m pip install -r requirements.txt
venv\Scripts\python manage.py migrate
```

## Test Credentials

- Username: `testuser`
- Password: `TestPassword123`

These are created automatically by a data migration.

## Usage

Run the development server:

```bash
venv\Scripts\python manage.py runserver
```

Send a POST request to `http://127.0.0.1:8000/api/login/` with JSON body:

```json
{
  "username": "testuser",
  "password": "TestPassword123"
}
```

The response includes an auth token:

```json
{
  "token": "<token>",
  "username": "testuser"
}
```

## Tests

```bash
venv\Scripts\python manage.py test
```

