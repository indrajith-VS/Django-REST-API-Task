from django.contrib.auth.hashers import make_password
from django.db import migrations


TEST_USERNAME = 'testuser'
TEST_PASSWORD = 'TestPassword123'


def create_test_user(apps, schema_editor):
    User = apps.get_model('auth', 'User')
    user, created = User.objects.get_or_create(username=TEST_USERNAME)
    if created:
        user.password = make_password(TEST_PASSWORD)
        user.is_active = True
        user.save()


def remove_test_user(apps, schema_editor):
    User = apps.get_model('auth', 'User')
    User.objects.filter(username=TEST_USERNAME).delete()


class Migration(migrations.Migration):

    dependencies = [
        ('auth', '0012_alter_user_first_name_max_length'),
    ]

    operations = [
        migrations.RunPython(create_test_user, remove_test_user),
    ]

