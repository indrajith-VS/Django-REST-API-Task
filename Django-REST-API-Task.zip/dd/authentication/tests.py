from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase


class LoginAPITest(APITestCase):
    def test_login_success_returns_token(self):
        payload = {
            'username': 'testuser',
            'password': 'TestPassword123',
        }
        url = reverse('api-login')

        response = self.client.post(url, payload, format='json')

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('token', response.data)
        self.assertEqual(response.data['username'], payload['username'])

    def test_login_failure_returns_error(self):
        payload = {
            'username': 'testuser',
            'password': 'wrong-password',
        }
        url = reverse('api-login')

        response = self.client.post(url, payload, format='json')

        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('non_field_errors', response.data)

# Create your tests here.
