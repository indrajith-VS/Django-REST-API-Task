const form = document.getElementById('login-form');
const resultBox = document.getElementById('login-result');

function setResult(message, type = 'info') {
    resultBox.textContent = message;
    resultBox.className = `result ${type}`;
}

form.addEventListener('submit', async (event) => {
    event.preventDefault();
    setResult('Requesting token...', 'info');

    const formData = new FormData(form);
    const payload = Object.fromEntries(formData.entries());

    try {
        const response = await fetch('/api/login/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(payload),
        });

        const data = await response.json();

        if (response.ok) {
            setResult(`Token: ${data.token}`, 'success');
        } else {
            const errors = data.non_field_errors || data.detail || 'Login failed.';
            setResult(`Error: ${Array.isArray(errors) ? errors.join(', ') : errors}`, 'error');
        }
    } catch (error) {
        setResult(`Network error: ${error.message}`, 'error');
    }
});

